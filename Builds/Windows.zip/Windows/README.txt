Welcome to Hacker Boi

This file will run through every aspect of the game. If you would like the play spoiler free, do not read this. 


~~Instructions~~

You are a hacker that must keep their Command Prompt running at all times. While this is running, you're hack
bar (top right) increases in value, and your point total increases. If the Command Prompt is not running, your
hack bar decreases. If your hack bar is empty, you lose. 

*Click Hack.exe to run the Command Prompt
*Mouse over the right arrow to go to your router. Hit the on button of your router to begin playing.

*As time goes on, the "lines" on your router may become compromised. 
 -Compromised router lines will turn yellow. Turn your router off, then on again to fix these.
 -If compromised lines are not fixed in time, they will be lost. Lost lines are red.
 -The more lines you've lost, the faster your hack bar will decrease while the Command Prompt is not running.
 -If all of your router lines are lost, the router will not work, and Command Prompt will not run.


*You may receive emails. Emails may be GOOD emails or BAD emails.
 -Good emails have a correct time, date, and spelling. They also come from a reputable source.
 -Open the contact's program (Contacts.txt) to check your contacts. 
 -If you receive an email with a contact you do not have, that is a bad email.

*GOOD EMAIL: You may reply to a good email with 3 responses. One response is good, one is neutral, and one is bad. 
 -A good response grants you additional hacker points.
 -A neutral response does nothing.
 -A bad response will result in random Ads popping up. 

*BAD EMAIL
 -If you reply to a bad email, random Ads will pop-up on your screen.
 -These ads simply get in the way.

*ERRORS
 -Every so often, your Command Prompt will run into an error.
 -The solutions to these errors varies.

*ERROR SOLUTIONS
 -Often times, errors will pop-up a minigame you must complete. 
 -Sometimes, errors require will give you a password in the error line, while enabling a file on your computer. To solve these errors, 
  you must open the file, and enter the password given to you. 
 -Finally, errors may require a passcode to be solved. Other hackers will send you an email with this passcode. Check your email, then enter the
  password given to solve these.

*Keep your Command Prompt running as long as possible. The longer it runs, the better your hacker score will be.